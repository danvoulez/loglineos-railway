# Pasta design/

Contém tema computável, paleta neon, fontes, animações e ícones SVG para sensores e spans.

- **theme.ts**: tema global (cores, fontes, espaçamento)
- **colors.ts**: paleta computável
- **fonts.ts**: fontes LogLine
- **animations.ts**: animações computáveis
- **icons/**: SVG para Brain, NFC, Mic, FaceScan

Proveniência: LogLine Foundation, Design System LogLine