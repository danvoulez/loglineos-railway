export const fonts = {
  inter: "'Inter', sans-serif",
  spaceGrotesk: "'Space Grotesk', sans-serif",
  jetBrainsMono: "'JetBrains Mono', monospace",
  title: '2rem',
  base: '1rem',
  weightBold: 700,
  weightMedium: 500,
}