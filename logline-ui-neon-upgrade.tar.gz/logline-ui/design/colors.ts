
export const colors = {
  background: '#0a0a0a',
  surface: '#1a1a1a',
  white: '#ffffff',
  black: '#000000',
  neonGreen: '#00FFAA',
  neonBlue:  '#00C8FF',
  neonPink:  '#FF29FF',
  neonPurple:'#C400FF',
  neonYellow:'#FFD600',
  danger: '#EF4444',
  border: '#333333',
  ghost: '#e0e0e0',
}
