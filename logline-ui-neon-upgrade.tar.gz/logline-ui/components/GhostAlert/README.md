# GhostAlert

Alerta visual para o modo efêmero (Ghost Mode).

## Uso

```tsx
<GhostAlert />
```

Exibe mensagem de que nenhum span será associado à identidade computável.

## Proveniência computável

- Proveniência: LogLine Foundation, Design System LogLine
- Versão: 2025.09
- Proveniência do código: danvoulez/loglineos-railway
- Última auditoria: 2025-09-22