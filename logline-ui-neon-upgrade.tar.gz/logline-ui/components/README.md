# Pasta components/

Componentes visuais do núcleo computável LogLine ID.

- **PasskeyButton.tsx**
- **AuthCard.tsx**
- **LogLineIDBadge.tsx**
- **DeviceStatus.tsx**
- **NeonBrain.tsx**
- **GhostAlert.tsx**
- **FooterLinks.tsx**

Todos seguem padrão computável e auditável.

Proveniência: LogLine Foundation, Design System LogLine