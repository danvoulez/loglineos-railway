'use client'

import React from 'react'

export const LogLineLogo = () => (
  <span className="text-4xl font-black text-white tracking-tight">LogLine</span>
)