# FooterLinks

Links institucionais e de consentimento computável.

## Uso

```tsx
<FooterLinks />
```

Inclui links para termos, consentimento, e LogLine Foundation.

## Proveniência computável

- Proveniência: LogLine Foundation, Design System LogLine
- Versão: 2025.09
- Proveniência do código: danvoulez/loglineos-railway
- Última auditoria: 2025-09-22