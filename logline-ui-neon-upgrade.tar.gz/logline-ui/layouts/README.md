# Pasta layouts/

Shells e containers de página computável.

- **AuthLayout.tsx**
- **AppShellLayout.tsx**

Proveniência: LogLine Foundation, Core UI