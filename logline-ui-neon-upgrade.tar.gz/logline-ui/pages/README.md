# Pasta pages/

Páginas centrais do fluxo computável.

- **index.tsx**: página principal
- **login.tsx**: login via Passkey
- **register.tsx**: registro LogLine ID
- **ghost.tsx**: modo ghost
- **consent.tsx**: consentimento computável
- **terms.tsx**: termos de uso

Proveniência: LogLine Foundation, Core UI