# Pasta hooks/

Hooks computáveis para estado, sensores, consentimento e spans.

- **usePasskey.ts**: autenticação WebAuthn
- **useGhostMode.ts**: modo ghost computável
- **useDeviceSensors.ts**: sensores do dispositivo
- **useSpans.ts**: auditoria de spans
- **useIdentity.ts**: identidade atual computável

Proveniência: LogLine Foundation, Core Logic