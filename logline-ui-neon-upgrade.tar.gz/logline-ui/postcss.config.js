module.exports = {
  plugins: [
    require('postcss-nested'),
    require('autoprefixer'),
    // Adicione outros plugins se quiser
  ],
}