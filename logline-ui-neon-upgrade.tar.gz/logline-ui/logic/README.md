# Pasta logic/

Funções utilitárias e núcleo computável.

- **logline.ts**: validação, origem, ghost, spans, DNA
- **audit.ts**: auditoria de spans
- **consent.ts**: consentimento computável
- **sensors.ts**: detecção e rotulagem de sensores

Proveniência: LogLine Foundation, Core Logic