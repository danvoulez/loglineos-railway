# Pasta __tests__/

Testes unitários dos componentes e lógica computável.

- **PasskeyButton.test.tsx**
- **LogLineIDBadge.test.tsx**
- **NeonBrain.test.tsx**
- **DeviceStatus.test.tsx**
- **GhostAlert.test.tsx**

Proveniência: LogLine Foundation, Test Coverage