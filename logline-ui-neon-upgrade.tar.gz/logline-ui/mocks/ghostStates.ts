// Mock para estados do modo Ghost
export const ghostStates = [
  { status: 'ghost', color: '#B100FF', label: 'Ghost Mode Ativo' },
  { status: 'normal', color: '#39FF14', label: 'Identidade Normal' },
]