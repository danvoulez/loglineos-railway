# Pasta mocks/

Mocks para estados, sensores, identidades computáveis e spans.

- **brainStates.ts**: estados do cérebro computável
- **sensorResponses.ts**: sensores detectados
- **fakeIdentities.ts**: identidades de exemplo
- **spansMock.ts**: spans computáveis mockados
- **ghostStates.ts**: estados ghost

Proveniência: LogLine Foundation, para testes e storybook computável