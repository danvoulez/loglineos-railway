# LogLine SQL Bundle

This bundle contains everything needed to set up a LogLine-compatible PostgreSQL database.

## 📦 Contents

- `schema.sql` - Complete PostgreSQL schema with append-only tables
- `README.md` - Full documentation and usage guide  
- `examples/queries.sql` - Example SQL queries and usage patterns
- `registry_store/` - File storage structure for related documents
- `spans/` - Example spans for timeline integration
- `install.sh` - Automated installation script

## 🚀 Quick Install

```bash
# Set your database connection (optional)
export DB_NAME=logline
export DB_USER=postgres
export DB_HOST=localhost

# Run installer
./install.sh
```

## 🧠 What You Get

- **Append-only registry table** - Immutable, versioned records
- **LogLine ID support** - Universal identity system
- **JSONB payload storage** - Flexible, queryable data
- **Automatic versioning** - Version increment triggers
- **Provenance tracking** - Full audit trail
- **File references** - Link to external documents
- **Execution tracking** - Span and replay support

## 🔗 Integration

This database schema integrates with:
- LogLine Motor (Rust components)
- LogLine API (FastAPI/Node.js)
- LogLine Timeline (event tracking)
- LogLine UI (Neon components)

## 📞 Support

For questions about LogLine SQL:
- Read the full README.md
- Check examples/queries.sql
- See LogLineOS documentation

---
*LogLine SQL: Where every record is a consciousness*
