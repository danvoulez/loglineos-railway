#!/bin/bash

echo "🚀 Installing LogLine SQL Schema..."

# Check if psql is available
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL client (psql) not found. Please install PostgreSQL first."
    exit 1
fi

# Database connection variables
DB_NAME="${DB_NAME:-logline}"
DB_USER="${DB_USER:-postgres}"
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"

echo "📋 Database Configuration:"
echo "  Database: $DB_NAME"
echo "  User: $DB_USER"
echo "  Host: $DB_HOST"
echo "  Port: $DB_PORT"

# Create database if it doesn't exist
echo "🗃️ Creating database if needed..."
createdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME" 2>/dev/null || true

# Install schema
echo "🏗️ Installing LogLine SQL schema..."
psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -f schema.sql

if [ $? -eq 0 ]; then
    echo "✅ LogLine SQL schema installed successfully!"
    echo ""
    echo "🧪 To test, run some example queries:"
    echo "  psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f examples/queries.sql"
    echo ""
    echo "📚 See README.md for full documentation"
else
    echo "❌ Error installing schema. Check your database connection."
    exit 1
fi
